Cloudfront URL: http://dwaccn22afvw.cloudfront.net/
S3 Endpoint URL: http://my-633040629926-bucket.s3-website-us-east-1.amazonaws.com/

